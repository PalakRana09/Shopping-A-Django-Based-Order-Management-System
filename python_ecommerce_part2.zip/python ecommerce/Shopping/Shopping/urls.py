"""
URL configuration for Shopping project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls.conf import include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from ecommerce import views
from django.contrib.auth import views as auth_views
from ecommerce import views
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('ecommerce.urls'))
    # path('',views.demo1),
    # path('index',views.demo1),
    # path('blog',views.demo2),
    # path('cart',views.demo3),
    # path('catagori',views.demo4),
    # path('checkout',views.demo5),
    # path('confirmation',views.demo6),
    # path('contact',views.demo7),
    # path('elements',views.demo8),
    # path('login',views.logins),
    # path('main',views.demo10),
    # path('product_list',views.demo11),
    # path('single-blog',views.demo12),
    # path('single-product',views.demo13),
    # path('image-uplod',views.demo14),
    # path('about',views.demo15),
    # path('cart_details/<int:id>',views.demo16),
    # path('logouts',views.logouts),
    # path('reigster_form',views.register_form),
    # path('test',views.testing),
    # path('account',views.demo17),
    # path('adminn', views.demo18),
    # path('delete/<int:id>',views.demo19),
    # path('change_password',views.change_password),
    # path('password_reset', views.password_reset_request, name='password_reset'),
    # path('password_reset_done', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    # path('reset/<uidb64>/<token>', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    # path('reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete')
]
if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)
        
# urlpatterns =[
#         path('password_reset/', auth_views.passwordrestview.as_view(), name='password_rest'),
#         path('password_reset/done', auth_views.passwordrestdoneview.as_view(), name='password_rest_done'),
#         path('password/<uidb64>/<token>', auth_views.passwordrestconfirmview.as_view(), name='password_rest_confirm'),
#         path('rest/done/', auth_views.passwordrestcompleteview.as_view(), name='password_rest_complete'),

# ]        
        

