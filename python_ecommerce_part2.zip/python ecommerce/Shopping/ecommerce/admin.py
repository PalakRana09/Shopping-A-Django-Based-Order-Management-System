from django.contrib import admin
from .models import products_model,cart,check_out
# Register your models here.
admin.site.register(products_model)
admin.site.register(cart)
admin.site.register(check_out)