from django.urls import path
from .views import*
urlpatterns = [
   path('',demo1),
   path('index',demo1),
   path('blog',demo2),
   path('cart',demo3),
   path('catagori',demo4),
   path('checkout',demo5),
   path('confirmation',demo6),
   path('contact',demo7),
   path('elements',demo8),
   path('login',logins),
   path('main',demo10),
   path('product_list',demo11),
   path('single-blog',demo12),
   path('single-product',demo13),
   path('image-uplod',demo14),
   path('about',demo15),
   path('cart_details/<int:id>',demo16),
   path('logouts',logouts),
   path('reigster_form',register_form),
   path('test',testing),
   path('account',demo17),
   path('adminn', demo18),
   path('delete/<int:id>',demo19),
   path('report',report),
   path('indexB',indexB),
   path('news',news),
   path('change_password',change_password),
   path('password_reset/', password_reset_request, name='password_reset'),
   path('password_reset_done', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
   path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
   path('reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete')
   
  #  path('forgot_password',forgot_password)
 ]