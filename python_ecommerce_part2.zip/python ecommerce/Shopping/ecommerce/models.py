from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class products_model(models.Model):
    products_name = models.CharField(max_length=20)
    product_price = models.CharField(max_length=10)
    product_image = models.ImageField(max_length=50,upload_to='images/')

class cart(models.Model):
    user_id = models.ForeignKey(User,on_delete=models.CASCADE)
    pr_id=models.ForeignKey(products_model,on_delete=models.CASCADE)

class check_out(models.Model):
    cartitems = models.ForeignKey(products_model,on_delete=models.DO_NOTHING)
    firstname = models.CharField(max_length=20)
    lastname = models.CharField(max_length=20)
    contact = models.CharField(max_length=20)
    emailid = models.CharField(max_length=20)
    country = models.CharField(max_length=20)
    address = models.CharField(max_length=50)
    addres = models.CharField(max_length=50)
    pincode = models.CharField(max_length=20)