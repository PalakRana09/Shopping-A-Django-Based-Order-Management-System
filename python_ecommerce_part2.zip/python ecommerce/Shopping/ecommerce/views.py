from django.shortcuts import render,HttpResponse,redirect

from . models import products_model,cart,check_out
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.auth.models import User
from django.db.models import Q
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.tokens import default_token_generator
from django.contrib.auth import views as auth_views
from django.contrib.auth.models import User
from django.contrib.sites.shortcuts import get_current_site
from django.core.mail import send_mail
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

def demo1(request):
    bb = products_model.objects.all()
    data = Paginator(bb,3)
    page_number = request.GET.get('page')
    try:
        page_obj = data.get_page(page_number)  # returns the desired page object
    except PageNotAnInteger:
        # if page_number is not an integer then assign the first page
        page_obj = data.page(1)
    except EmptyPage:
        # if page is empty then return last page
        page_obj = data.page(data.num_pages)
        
    context = {'data': page_obj}
    return render(request,'index.html',context)

def demo2(request):
    return render(request,'blog.html')

def demo3(request):
    userid = request.user.id
    subtotal = 0
    cart_ids=cart.objects.filter(user_id=userid)
    for i in cart_ids:
        subtotal = subtotal + int(i.pr_id.product_price)
    print(subtotal,'=================')
    cart_data = cart.objects.filter(user_id=userid)

    # cart_data = cart.objects.all()
    return render(request,'cart.html',{'cart_data':cart_data, 'subtotal':subtotal})

def demo4(request):
    return render(request,'catagori.html')    

def demo5(request):
    userid = request.user.id
    subtotal = 0
    cart_detail = cart.objects.filter(user_id=userid)
    for i in cart_detail:
        subtotal = subtotal + int(i.pr_id.product_price)
    print(subtotal,'=================')
    if request.method == 'POST':
        firstname = request.POST.get('fname')
        lastname = request.POST.get('lname')
        contact = request.POST.get('number')
        emailid = request.POST.get('compemailany')
        country = request.POST.get('country')
        address1 = request.POST.get('add1')
        address2 = request.POST.get('add2')
        pincode = request.POST.get('zip')
        print(emailid)
        # print(firstname,lastname,contact,emailid,country,address1,address2,pincode)
        ids = cart.objects.filter(user_id=userid)
        for i in ids:
            print('==================')
            idd = cart.objects.get(id=i.id)

            prid = products_model.objects.get(id=idd.pr_id.id)
            billing_detail=check_out(cartitems=prid,firstname=firstname,lastname=lastname,contact=contact,emailid=emailid,country=country,address=address1,addres=address2,pincode=pincode)
            billing_detail.save()

            # idd.delete()
        cart.objects.filter(user_id=userid).delete()
        subject = 'Order confirmation'
        message = 'order placed sohneo  '
        from_email = settings.EMAIL_HOST_USER
        recipient_list = [emailid] 
        send_mail(subject, message, from_email, recipient_list)
        print('cart is empty----')
        return HttpResponse('item added to cart suucessfully')

    return render(request,'checkout.html',{"pr_detail":cart_detail,"subtotal" :subtotal,"Total":subtotal+150})  
  
def demo6(request):
    return render(request,'confirmation.html')    

def demo7(request):
    return render(request,'contact.html')    

def demo8(request):
    return render(request,'elements.html')    
  

def demo10(request):
    return render(request,'main.html')    

def demo11(request):
    return render(request,'product_list.html')    

def demo12(request):
    return render(request,'single-blog.html')    

def demo13(request):
    return render(request,'single-product.html')   

def demo14(request):
    return render(request,'image-uplod.html')  

def demo15(request):
    return render(request,'about.html') 

def demo17(request):
    user = request.user
    if user.is_authenticated:
        return render(request, 'account.html', {'user': user})
    else:
        return redirect("logins")
    # return render(request,'account.html')   

# def demo16(request,id):
#     ids=products_model.objects.get(id=id)
#     obj=cart(pr_id=ids)
#     obj.save()
#     return HttpResponse('Item added to your cart successfully')

def demo16(request,id):
    print(' this is to add items to your cart')
    user_id = request.user.id
    uid = User.objects.get(id=user_id)
    pr_id = products_model.objects.get(id=id)
    obj=cart(user_id =uid,pr_id=pr_id)
    obj.save()
    return render (request,'cart_detail.html')
# def demo1(request):
#     return render(request,'index.html')    


def home(request):
    if request.method == 'POST':
        produt_name = request.POST.get('prname')
        produt_price = request.POST.get('prprice')
        produt_image = request.FILES['primage']
        print(produt_name,produt_price,produt_image,'==============')
        product = products_model(products_name=produt_name,product_price=produt_price,product_image=produt_image)
        product.save()
        return HttpResponse('product added successfully')
    return render(request,'image_upload.html')


def register_form(request):
    if request.method == "POST":
        name = request.POST['username']
        email = request.POST['mail']
        passw = request.POST['pass']
        print(name,email,passw,'------------------')
        obj = User.objects.create_user(username=name,email=email,password=passw)
        obj.save()
        return HttpResponse('user created successfully !!!')
    return render(request,'register.html')
    

def logouts(request):
    logout(request)
    return redirect(demo1)

def logins(request):
    if request.method == "POST":
        name = request.POST['name']
        passwd = request.POST['password']
        obj = authenticate(username = name,password = passwd)
        if obj:
            login(request,obj)
            return redirect(demo1)
        else:
            return HttpResponse('invalid credentials')
    return render(request,'login.html')
 
def testing(request):
    total = 0
    ids = cart.objects.all()
    for i in ids:
        # print('======',i.pr_id.product_price)
        total = total+int(i.pr_id.product_price)
    print(total,'===================')
    return HttpResponse('testing....')

# def send_email(request):
#     email='galoyok243@flexvio.com'
#     subject = 'Order confirmation'
#     message = 'order placed sohneo  '
#     from_email = settings.EMAIL_HOST_USER
#     recipient_list = [email]
#     send_mail(subject, message, from_email, recipient_list)
#     return HttpResponse('Email sent successfully!')

# Create your views here.

from django.contrib.auth.forms import PasswordChangeForm
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('Password changed')
    
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'change_password.html', {'form':form})

def demo18(request):
    return render(request,'adminn.html') 

def demo19(request, id):
    dd= cart.objects.get(id=id)
    dd.delete()
    return redirect(demo3)

from django.contrib.auth.tokens import default_token_generator
from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse, HttpResponseRedirect
from django.template.loader import render_to_string, get_template
from django.contrib.auth.views import PasswordResetView as BasePasswordResetView, PasswordResetConfirmView as BasePasswordResetConfirmView
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect
from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage

def password_reset_request(request):
    if request.method == "POST":
        password_reset_form = PasswordResetForm(request.POST)
        if password_reset_form.is_valid():
            data = password_reset_form.cleaned_data['email']
            associated_users = User.objects.filter(Q(email=data))
            if associated_users.exists():
                for user in associated_users:
                    subject = "Password Reset Requested"
                    email_template_name = "password_reset_email.html"
                    c = {
                    "email":user.email,
                    'domain':'127.0.0.1:8000',
                    'site_name': 'Website',
                    "uid": urlsafe_base64_encode(force_bytes(user.pk)),
                    "user": user,
                    'token': default_token_generator.make_token(user),
                    'protocol': 'http',
                    }
                    email = render_to_string(email_template_name, c)
                    try:
                        send_mail(subject, email, 'ranapalak019@gmail.com' , [user.email], fail_silently=False)
                    except BadHeaderError:
                        return HttpResponse('Invalid header found.')
                    
                return redirect ("/password_reset_done")
            else:
                return HttpResponse("user not exist")    
    password_reset_form = PasswordResetForm()
    return render(request=request, 
                        template_name="password_reset.html", 
                        context={"form":password_reset_form})

    from fpdf import FPDF

from django.http import FileResponse

from django.shortcuts import render

from fpdf import FPDF

def indexB(request):
    context = {}
    return render(request, "indexB.html", context)

def report(request):
    sales = [
        {"item": "Speaker", "amount": "$120,00"},
        {"item": "UPS", "amount": "$10,00"},
        {"item": "PS5", "amount": "$1 000 000,00"},
    ]

    pdf = FPDF('L', 'mm', 'A4')
    pdf.add_page()
    pdf.set_font('courier', 'B', 16)
    pdf.cell(40, 10, 'Customer Order Items:', 0, 1)
    pdf.cell(40, 10, '', 0, 1)
    pdf.set_font('courier', '', 12)
    pdf.cell(200, 8, f"{'Item'.ljust(50)} {'Amount'.rjust(20)}", 1, 1)
    pdf.line(10, 30, 150, 30)
    pdf.line(10, 38, 150, 38)

    for line in sales:
        pdf.cell(200, 8, f"{line['item'].ljust(50)} {line['amount'].rjust(20)}", 0, 1)

    pdf.output('report.pdf', 'F')
    return FileResponse(open('report.pdf', 'rb'), as_attachment=True, content_type='application/pdf')

# from django.urls import path
# from . import views

# urlpatterns = [
#     path('report/', views.report, name='report'),
# ]

# def forgot_password(request):
    # if request.method == 'POST':
    #     form = PasswordResetForm(request.POST)
    #     if form.is_valid():
    #         email = form.cleaned_data['email']
    #         users = user.objects.filter(email=email)
    #         for user in users:
    #             token = default_token_generator.make_token(user)

    #             uid = urlsafe_base64_encode(force_bytes(user.pk))
    #             reset_url = request.build_absolute_url(
    #                 f"/ reset /{uid}/{token}/" 
    #             )

    #             current_site = get_current_site(request)
    #             subject = 'Reset your password'
    #             message = render_to_string(
    #               'registration/resetpassword.html', {
    #                     'user': user,
    #                     'domain': current_site.domain,
    #                     'rest_url': reset_url,
    #                     })
    #             send_mail(subject,message,'ranapalak019@gmail.com',[email])

    #         else:
    #             form = PasswordResetForm()
    #             return render(request, 'forgot_password.html', {'form':form})



from newsapi import NewsApiClient
def news(request):
    newsapi = NewsApiClient(api_key='df9e71e1f6f942ed98f67bc3d6511d64')

    # /v2/everything
    all_articles = newsapi.get_everything(
        q='business',
        sources='bbc-news,the-verge,CNN',
        domains='bbc.co.uk,techcrunch.com',
        from_param='2024-04-01',  # Adjusted start date
        to='2024-04-06',  # Adjusted end date (current date)
        language='en',
        sort_by='relevancy',
        page=2
    )

    print("API Response:", all_articles)  # Debug print statement

    # Check if data is retrieved
    if all_articles['status'] == 'ok':
        articles = all_articles['articles']
    else:
        return HttpResponse("Error fetching news data")

    print("Number of Articles:", len(articles))  # Debug print statement

    # Pass the articles data to the template
    context = {
        'articles': articles
    }

    # Render the HTML template with the context
    return render(request, 'news.html', context)

